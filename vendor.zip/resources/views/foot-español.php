<footer id="footer">
            <div class="container footer-container">
                <div class="row text-center">

                    <div class='col-sm-6 col-md-4'>
                        <div id="recent-posts-3" class="footer_widget widget widget_recent_entries">
                            <h5 class="widget-title">Consulta</h5>
                            <div id="separadordjm2"></div>
                            <ul>
								<li><a href="nosotros.html">Nosotros</a></li>
								<li><a href="testimonios.html">Testimonios</a></li>
                                <li><a href="terminos-y-condiciones.html">Términos & Condiciones</a></li>
                                <li><a href="preguntas-frecuentes.html">Preguntas Frecuentes</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class='col-sm-6 col-md-4 footer-column-4'>
                        <div id="text-3" class="footer_widget widget widget_text">
                            <h5 class="widget-title">Contacto</h5>
                            <div id="separadordjm2"></div>
                            <div class="textwidget">
								<i class="fa fa-envelope"></i><a style="color: rgba(248, 248, 248, 0.5)" href="mailto:operaciones@andeanexclusive.com"> operaciones@andeanexclusive.com</a>
								<br>
								<i class="fa fa-mobile"></i> <a href='https://bit.ly/3kYXpXr' target="_blank" style="color: rgba(248, 248, 248, 0.5)">+51 979 721 194</a> 
								<br>
                                <i class="fa fa-phone"></i> +51 084 242791
                                <br>
                                <i class="fa fa-map-marker"></i> Balconcillo Alto c-6 Cusco - Perú
                            </div>
                        </div>
                    </div>
                    <div class='col-sm-6 col-md-4 footer-column-4'>
                        <div id="search-4" class="footer_widget widget widget_search">
                            <h5 class="widget-title">Sociales</h5>
                            <div id="separadordjm2"></div>
                        </div>
                        <div id="tt_sociallinkswidget-4" class="footer_widget widget widget_social">
                            <div class="social-links">
                                <a href="https://www.facebook.com/AndeanExclusiveTours" rel="nofollow" target="_blank"><i  class="fa fa-facebook fa-2x"></i></a>
                                <a href="https://twitter.com/ReservasAndean" rel="nofollow" target="_blank"><i  class="fa fa-twitter fa-2x"></i></a>
                                <a href="https://n9.cl/cjx4" target="_blank" rel="nofollow"><i  class="fa fa-tripadvisor fa-2x"></i></a>
                                <a href="https://www.instagram.com/andean.exclusive/" rel="nofollow" target="_blank"><i  class="fa fa-instagram fa-2x"></i></a>
                                <a href="https://www.pinterest.com/andeanexcsive/" rel="nofollow" target="_blank"><i  class="fa fa-pinterest fa-2x"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sub-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 text-center">
                                <div class="widget">
                                    <p>Copyright 2019 &copy; Andean Exclusive Tours | Todos los derechos reervados | <a href="https://www.facebook.com/DjmWebMaster" rel="nofollow" id="afoot" target="_blank">DJM2</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </footer>