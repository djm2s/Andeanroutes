<li class='menu-item'><a href="index-español" @if(request()->is('index-español')) id="active" @endif>Inicio</a></li>
<li class='menu-item'><a href="experiencias" @if(request()->is('experiencias')) id="active" @endif>Populares</a></li>
<li class='menu-item'><a href="alrededor-de-peru" @if(request()->is('alrededor-de-peru')) id="active" @endif>Tours en Perú</a></li>
<li class='menu-item'><a href='caminatas-peru' @if(request()->is('caminatas-peru')) id="active" @endif>Aventuras</a></li>
<li class='menu-item'><a href='blog-español' @if(request()->is('blog-español')) id="active" @endif>Blog</a></li>