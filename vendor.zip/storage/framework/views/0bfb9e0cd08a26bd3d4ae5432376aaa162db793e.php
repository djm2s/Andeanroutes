<li class="menu-item"><a href="/" <?php if(request()->is('/')): ?> id="active" <?php endif; ?>>Home</a></li>
<li class='menu-item'><a href="experiences" <?php if(request()->is('experiences')): ?> id="active" <?php endif; ?>>Popular</a></li>
<li class='menu-item'><a href="around" <?php if(request()->is('around')): ?> id="active" <?php endif; ?>>Around Perú</a></li>
<li class='menu-item'><a href='adventures' <?php if(request()->is('adventures')): ?> id="active" <?php endif; ?>>Adventures</a></li>
<li class='menu-item'><a href='blog' <?php if(request()->is('blog')): ?> id="active" <?php endif; ?>>blog</a></li><?php /**PATH C:\xampp\htdocs\Andeanroutes\resources\views/layouts/menu.blade.php ENDPATH**/ ?>