<li class='menu-item'><a href="../index-español">Inicio</a></li>
<li class='menu-item'><a href="../experiencias">Populares</a></li>
<li class='menu-item'><a href="../alrededor-de-peru">Tours en Perú</a></li>
<li class='menu-item'><a href='../caminatas-peru'>Adventuras</a></li>
<li class='menu-item'><a href='../blog-español' id="active">Blog</a></li><?php /**PATH C:\xampp\htdocs\Andeanroutes\resources\views/layouts/menu-blog-español.blade.php ENDPATH**/ ?>