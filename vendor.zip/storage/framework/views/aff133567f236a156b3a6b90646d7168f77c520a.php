<li class='menu-item'><a href="index-español" <?php if(request()->is('index-español')): ?> id="active" <?php endif; ?>>Inicio</a></li>
<li class='menu-item'><a href="experiencias" <?php if(request()->is('experiencias')): ?> id="active" <?php endif; ?>>Populares</a></li>
<li class='menu-item'><a href="alrededor-de-peru" <?php if(request()->is('alrededor-de-peru')): ?> id="active" <?php endif; ?>>Tours en Perú</a></li>
<li class='menu-item'><a href='caminatas-peru' <?php if(request()->is('caminatas-peru')): ?> id="active" <?php endif; ?>>Aventuras</a></li>
<li class='menu-item'><a href='blog-español' <?php if(request()->is('blog-español')): ?> id="active" <?php endif; ?>>Blog</a></li><?php /**PATH C:\xampp\htdocs\Andeanroutes\resources\views/layouts/menu-español.blade.php ENDPATH**/ ?>