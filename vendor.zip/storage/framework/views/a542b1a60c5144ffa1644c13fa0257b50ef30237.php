<li class="menu-item"><a href="../">Home</a></li>
<li class='menu-item'><a href="../experiences" >Popular</a></li>
<li class='menu-item'><a href="../around" >Around Perú</a></li>
<li class='menu-item'><a href='../adventures'>Adventures</a></li>
<li class='menu-item'><a href='../blog' id="active">blog</a></li><?php /**PATH C:\xampp\htdocs\Andeanroutes\resources\views/layouts/menu-blog.blade.php ENDPATH**/ ?>