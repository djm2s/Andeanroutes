
<link rel="stylesheet" href="css/wasa.css">
<!--Boton chat de wasa-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<a href="https://bit.ly/3kYXpXr" class="float" target="_blank" rel="nofollow">
		<i class="fa fa-whatsapp my-float"></i>
	</a>
    <!--End Boton wasa--><?php /**PATH C:\xampp\htdocs\Andeanroutes\resources\views/layouts/wasa.blade.php ENDPATH**/ ?>