<!DOCTYPE html>
<html lang="en-US" class="no-js">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <title>Encuentre su experiencia, su destino en Perú!</title>
    <meta name="keywords" content="Experiencias únicas en Perú, tours de lujo, Lima, Cusco, Exclusivo Cusco" />
    <meta property="og:description" content="Te presentamos una lista de experiencias de lujo para disfrutar en Perú." />
    <meta property="og:url" content="https://andeanexclusive.com/experiencias.html">
    <meta property="og:title" content="Encuentre su experiencia en Perú!">
    <meta property="og:type" content="webside">
    <meta property="og:image" content="https://www.andeanexclusive.com/img/Machu-Picchu-exclusive.jpg" />
    <meta name="author" content="Web Masters DJM2" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans&display=swap" rel="stylesheet">
    <link rel='stylesheet' href='styles/bootstrap.minbb49.css' type='text/css' media='all' />
    <link rel='stylesheet' href='styles/js_composer.min5243.css' type='text/css' media='all' />
    <link rel="icon" type="image/png" href="img/logoico.png">
    <link rel="stylesheet" href="css/wasa.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="styles/estilo.css">
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css">
    <script type='text/javascript' src='js/jquery4a5f.js'></script>
    <script type='text/javascript' src='js/mediaelement-and-player.min45a0.js'></script>
</head>

<body class="home page-template-default page page-id-44 wpb-js-composer js-comp-ver-5.4.5 vc_responsive">
    <!--Boton chat de wasa-->
    
    <!--End Boton wasa-->
    <div class="wrapper">
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="header-wrapper">
                            <div class="site-branding">
                                <a href="index-español" rel="home" class="logo-text-link">
                                    <div class="logo2"></div>
                                </a>
                            </div>
                            <nav class="main-nav">
                                <ul class="one-page-menu">
                                    <?php echo $__env->make('layouts.menu-español', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <li id="display" class="menu-has-children">
                                        <a>
                                            <button type="button" class="btn botondjm">Idioma <i class="fa fa-chevron-down"></i></button>
                                        </a>
                                        <ul>
                                            <li><a>Español</a></li>
                                            <li><a href="experiences">Ingles</a></li>
                                        </ul>
                                    </li>
                                    <li id="wasanum" class='menu-item'><a href='https://bit.ly/3kYXpXr' target="_blank">+51 979 721 194</a></li>
                                    <li id="display2" class="menu-has-children">
                                        <a href=""><img src="../img/españa.png" alt="Idioma Tarvel Agency"></a>&nbsp;&nbsp;&nbsp;&nbsp;
                                        <a href="experiences"><img src="../img/ingles.png" alt="english Travel Agency"></a>
                                    </li>
                                </ul>
                                <a href="javascript:;" id="mobile-menu"><span></span></a>
                                <a href="javascript:;" id="close-menu"></a>
                            </nav>

                        </div>

                    </div>
                </div>
            </div>
        </header>
        <section class="section-content no-padding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <article class="blog-item blog-single">
                            <div class="entry-excerpt">
                                <div data-vc-full-width="true" data-vc-full-width-init="false" data-onepage-title="Home" data-onepage-slug="home" class="vc_row wpb_row vc_row-fluid experiencias vc_row-has-fill vc_row-o-full-height vc_row-o-columns-middle vc_row-o-content-middle vc_row-flex">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner vc_custom_1461317698190">
                                            <div class="wpb_wrapper">
                                                <div class='carousel-headings '>
                                                    <div class='swiper-container'>
                                                        <div class='swiper-wrapper'>
                                                            <div class='swiper-slide'>
                                                                <div class='cover-text ph5 text-light text-center pv8 pvb0'>
                                                                    <h1>Tours populares en Perú</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_row-full-width vc_clearfix"></div>
                                <div data-onepage-title="Services" data-onepage-slug="services" class="vc_row wpb_row vc_row-fluid vc_custom_1461248392126">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner vc_custom_1461227943574">
                                            <div class="wpb_wrapper">
                                                <div class='heading  text-center '>
                                                    <div id="separador"></div>
                                                    <h3>En Demanda</h3>
                                                    <div id="separadordjm"></div>
                                                </div>
                                            </div>
                                            <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1461228476759">
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228417147">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href='cusco-4-dias-3-noches' class='entry-link'><img srcset="img/thumbnail/destino-per.JPG 1000w, img/thumbnail/destino-per.JPG 500w" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>CUSCO SENSASIONAL</h3>
                                                                    <div class='info'>
                                                                        Duración: 4 días
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href='cusco-4-dias-3-noches' class='button'>Más Info</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228449756">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href="peru-8-dias-7-noches" class='entry-link'><img width="400" height="400" src="img/thumbnail/llama-peru.JPG" class="attachment-post-grid-s size-post-grid-s" alt="llamas peru cusco" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Perú 8 días</h3>
                                                                    <div class='info'>
                                                                        Lima, Cusco, Machu Picchu, Puno
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a class='button' href="peru-8-dias-7-noches">Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228417147">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href="machupicchu-acelerado" class='entry-link'><img src="img/thumbnail/Machupicchu_AET.jpg" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Machu Picchu Acelerado</h3>
                                                                    <div class='info'>
                                                                        Duración: 3 días
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href="machupicchu-acelerado" class='button'>Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228449756">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href="peru-6-dias-5-noches" class='entry-link'><img width="400" height="400" src="img/thumbnail/cusco-01.JPG" class="attachment-post-grid-s size-post-grid-s" alt="Tour in Cusco" srcset="img/thumbnail/cusco-01.JPG 400w" sizes="(max-width: 400px) 100vw, 400px" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Peru 6 días</h3>
                                                                    <div class='info'>
                                                                        Lima, Cusco, Machu Picchu
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href="peru-6-dias-5-noches" class='button'>Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="wpb_wrapper">
                                                <div class='heading  text-center '>
                                                    <div id="separador"></div>
                                                    <h3>ESCAPADA DEL DIA</h3>
                                                    <div id="separadordjm"></div>
                                                </div>
                                            </div>
                                            <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1461228476759">
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228442150">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href="hiram-bingham" class='entry-link'><img width="400" height="400" src="img/thumbnail/Machupicchu.jpg" class="attachment-post-grid-s size-post-grid-s" alt="Hiram Bingham Cusco Perú" srcset="img/thumbnail/Machupicchu.jpg 400w" sizes="(max-width: 400px) 100vw, 400px" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Machu Picchu por Hiram Bingham</h3>
                                                                    <div class='info'>
                                                                        Duración: 1 día
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href="hiram-bingham" class='button'>Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228442150">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href="mercado-urubamba" class='entry-link'><img width="400" height="400" src="img/thumbnail/urubamba-market.png" class="attachment-post-grid-s size-post-grid-s" alt="mercado Urubamba - cusco" sizes="(max-width: 400px) 100vw, 400px" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Mercado Urubamba</h3>
                                                                    <div class='info'>
                                                                        Duración: 1 día
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href="mercado-urubamba" class='button'>Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228449756">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href="ciclismo" class='entry-link'><img width="400" height="400" src="img/thumbnail/biking-cusco.jpg" class="attachment-post-grid-s size-post-grid-s" alt="ciclismo en el valle sagrado" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Ciclismo en el cielo</h3>
                                                                    <div class='info'>
                                                                        Duración: 1 día
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a class='button' href="ciclismo">Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228449756">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href="valle-sagrado" class='entry-link'><img width="400" height="400" src="img/thumbnail/chincheros.jpg" class="attachment-post-grid-s size-post-grid-s" alt="Valle Sagrado Perú" srcset="img/thumbnail/chincheros.jpg 400w" sizes="(max-width: 400px) 100vw, 400px" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Valle Sagrado</h3>
                                                                    <div class='info'>
                                                                        Duración: 1 día
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a class='button' href="valle-sagrado">Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="wpb_wrapper">
                                                <div class='heading  text-center '>
                                                    <div id="separador"></div>
                                                    <h3>LO MEJOR DE PERÚ</h3>
                                                    <div id="separadordjm"></div>
                                                </div>
                                            </div>
                                            <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1461228476759">
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228417147">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href='puno-3-dias-tour' class='entry-link'><img src="img/thumbnail/puno-peru.JPG" alt="tours en Puno" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Puno</h3>
                                                                    <div class='info'>
                                                                        Duración: 3 días
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href='puno-3-dias-tour' class='button'>Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228442150">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href="peru-7-dias-6-noches" class='entry-link'><img width="400" height="400" src="img/thumbnail/arequipa-perú.JPG" class="attachment-post-grid-s size-post-grid-s" alt="Arequipa perú" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Perú 7 días</h3>
                                                                    <div class='info'>
                                                                        Lima, Cusco, Machu Picchu, Puno
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href="peru-7-dias-6-noches" class='button'>Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228449756">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href='lima-tour-3-dias' class='entry-link'><img width="400" height="400" src="img/thumbnail/ceviche-gambas.jpg" class="attachment-post-grid-s size-post-grid-s" alt="" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Lima - Perú</h3>
                                                                    <div class='info'>
                                                                        Duración: 3 días
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href='lima-tour-3-dias' class='button'>Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-3">
                                                    <div class="vc_column-inner vc_custom_1461228449756">
                                                        <div class="wpb_wrapper">
                                                            <div class='travel-item'>
                                                                <div class='entry-img'>
                                                                    <a href='#' class='entry-link'><img width="400" height="400" src="img/thumbnail/mono-amazonas.jpg" class="attachment-post-grid-s size-post-grid-s" alt="mono amazonas" /></a>
                                                                </div>
                                                                <div class='entry-info'>
                                                                    <h3>Perú 15 días</h3>
                                                                    <div class='info'>
                                                                        Lima, Cusco, Machu Picchu, Puno, Arequipa
                                                                    </div>
                                                                    <div class='readmore'>
                                                                        <a href='#' class='button'>Leer más</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="separador"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="vc_row-full-width vc_clearfix"></div>
                    </div>
                    </article>
                </div>
            </div>
    </div>
    </section>
    <?php echo $__env->make('layouts.foot-español', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script type='text/javascript' src='js/swiper.minbb49.js?ver=5.2.2'></script>
    <script type='text/javascript' src='js/isotope.pkgd.min5243.js?ver=5.4.5'></script>
    <script type='text/javascript' src='js/scripts.js'></script>

</body>

</html>
<?php echo $__env->make('layouts.wasa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Andeanroutes\resources\views/experiencias.blade.php ENDPATH**/ ?>