<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use League\CommonMark\Block\Element\Document;

class HomeController extends Controller
{
}
